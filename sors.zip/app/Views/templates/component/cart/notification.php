<div class="wrapper" ng-click="open()">
    <div class="icon"></div>
    <div class="label">products: </div>
    <div class="count">{{count}}</div>
</div>
